import { log } from "node:console";
import readline from "readline";

const rl = readline.createInterface({
    input:process.stdin,
    output:process.stdout
})

const todos = [];

const showMenu = () => {
    console.log("\n1: Add a Task");
    console.log("\n2. View Tasks");
    console.log("\n3: Exit");

    rl.question("Choose an option : ",handleInput)
}

const handleInput = (option)=>{
    if(option === "1"){
        rl.question("Enter the task: " , (task)=>{
            todo.push(task);
            console.log("Task added: ",task);
            showMenu();
        })   
    }else if(option === "1"){
        console.log("\n Your Todo Lists");
        todos.forEach((task,index)=>{
            console.log(`${index+1}. ${task}`);
            showMenu();
        })

        
    }else if(option === "3"){
        console.log("GoodBye");
        rl.close();
        
    }else{
        console.log("Invalid option");
        showMenu();
        
    }
}
showMenu();