const { log } = require("console");
const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");

const PORT = 3000;
const fileName = "log.txt";
const filePath = path.join(__dirname,fileName);
const server = http.createServer((req,res)=>{
    const url = req.url;
    const jgurl = "https://official-joke-api.appspot.com/random_joke";
    const method = req.method;
    const time = new Date().toLocaleString();
    const logs = `URL : ${url} | Method : ${method}" | Time : ${time}\n`;
    fs.appendFile(filePath,logs,(err)=>{
        if(err){
            console.error(err);
        }else{
            console.log("File successfully updated");  
        }
    })
    if(url === "/"){
        res.write(`<h1>Do you want to laugh? Go to <a href="/joke">Joker</a></h1>`);
        res.end();
    }else if(url === "/joke"){
        https.get(jgurl,(responce)=>{
            let data = "";
            responce.on("data",(chunk)=>{
                data += chunk;
            });
        
            responce.on('end',()=>{
            const joke = JSON.parse(data);
                const JokeasString = `
                    <div style="font-family:sans-serif">
                        <h2>${joke.type}</h2>
                        <p><b>${joke.setup}</b></p>
                        <p>${joke.punchline}</p>
                    </div>
                `;
                const jokeFilePath = path.join(__dirname,"jokes");
                fs.appendFile(jokeFilePath,JokeasString+"\n",(err)=>console.error(err));
                res.write(JokeasString);
                res.end();
            
            
        });
        responce.on("error",(err)=>{
            console.log("error fetching the joke");
            
        });
        });
    }else{
        res.write("404 Page not found");
        res.end();
    }

});

server.listen(PORT,()=>{
    console.log(`Server is Live on PORT ${PORT}`);
    
});