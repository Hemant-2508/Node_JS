
const http = require("http");
const path = require("path");
const fs = require("fs");

const server = http.createServer((req,res)=>{

    const url = req.url;
    const method = req.method;
    const date = new Date().toLocaleString();

    const string = `Route : ${url} , Method : ${method} , Date & time : ${date}\n`;

    // console.log(string);

    const fileName = "log.txt";
    const filePath = path.join(__dirname,fileName);

    fs.appendFile(filePath,string,"utf-8",(err)=>{
        if(err){
            console.log(err);
        }else{
            console.log("File written successfully");
            
        }
    });


    if(url === '/'){
        res.write("This is homepage");
        res.end();
    }else if(url === "/about"){
        res.write("This is about page");
        res.end();
    }else if(url === "/contact"){
        res.write("This is contact page");
        res.end();
    }else{
        res.write("404 Error page not found");
        res.end();
    }

})


const PORT = 7000;
server.listen(PORT,()=>{
    console.log(`Listening server at PORT ${PORT}`);
    
})