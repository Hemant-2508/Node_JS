
const http = require("http");
const fs = require("fs");
const path = require("path");
const filePath = path.join(__dirname, "count.txt");

let counter = {
    count : 0
}
if(!fs.existsSync(filePath))
fs.writeFileSync(filePath,JSON.stringify(counter),"utf-8");

const server = http.createServer((req,res)=>{
    const url = req.url;
    console.log("Run");
    
    if(url === "/count"){
        if(!fs.existsSync(filePath)){
            counter['count'] += 1;
            fs.writeFileSync(filePath,JSON.stringify(counter),"utf-8");
            res.write("file created succesfully and count is "+counter["count"]);
        
        }else{
            counter = JSON.parse(fs.readFileSync(filePath,"utf-8"));
            counter["count"]+=1;
            fs.writeFileSync(filePath,JSON.stringify(counter),"utf-8");
            res.write("count : "+counter["count"]);
        }
        res.end();
    }else{
        res.write("404 error page not found");
        res.end();
    }
});


server.listen(7000,()=>{console.log("server running!")});