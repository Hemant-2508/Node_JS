const fs = require("fs");
const path = require("path");
const http = require("http");

const fileName = "severlogsTask1.txt";
const filePath = path.join(__dirname,fileName);

const server = http.createServer((req,res)=>{
    const url = req.url;
    const method = req.method;
    const time = new Date().toLocaleString();

    const log = `URL : ${url}, Method : ${method}, Time : ${time} \n`;

    fs.appendFile(filePath,log,(err)=>{
        if(err){
            console.error(err);
        }else{
            console.log("sever log updated successfully");
        }
    })

    if(url === "/"){
        res.write("This is Homepage");
        res.end();
    }else if(url === "/about"){
        res.write("This is about page");
        res.end();
    }else if(url === "/contact"){
        res.write("This is contancts ");
        res.end();
    }else{
        res.write("404 error Page not found");
        res.end();
    }


});

const PORT = 3000;
server.listen(PORT,()=>console.log(`Listening on PORT ${3000}`))