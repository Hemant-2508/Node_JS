// Scenario Question: Website Visitor Log + System Monitor
// Question

// Create a Node.js server that performs the following tasks:

// Routes to implement:

// /visit
// → Write visitor entry with timestamp into visitors.log

// /logs
// → Read and display visitor logs

// /copy-logs
// → Copy logs into backup.log

// /clear-logs
// → Delete the visitor log file

// /system-info
// → Display system information:

// Hostname

// OS platform

// CPU model

// Number of cores

// Total memory

// Free memory

// Uptime

// Use only Node.js core modules:

// http

// fs

// os

// path




const fs = require("fs");
const path = require("path");
const http  = require("http");
const os = require("os");

const PORT = 7000;
const visitorLogPath = path.join(__dirname,"visitorlog.txt");
const backupLogPath = path.join(__dirname,"backuplog.txt");

const server = http.createServer((req,res)=>{
    const url = req.url;
    const date = new Date().toLocaleString();
    const method = req.method;
    
    if(url === "/visit"){
        const log = `Date & Time : ${date} | Route : ${url} | Method : ${method}\n`;
        fs.appendFileSync(visitorLogPath,log,"utf-8");
        res.write("visited visit page");
        res.end();
    }else if(url === "/logs"){
        const data = fs.readFileSync(visitorLogPath,"utf-8");
        if(data){
            res.write(data);
            res.end();
        }else{
            res.write("No data found in visitor log");
            res.end();
        }
    }else if(url === "/copy-logs"){
        if(fs.existsSync(visitorLogPath)){
        const data = fs.readFileSync(visitorLogPath,"utf-8");
        if(data){
            fs.writeFileSync(backupLogPath,data,"utf-8");
            res.write("data successfully copied");
            res.end();
        }else{
            res.write("These is no data in visitor Log or it doesn't exists")
        }}else{
            res.write("These is no data in visitor Log or it doesn't exists")

        }
        res.end();
    }else if(url === "/clear-logs"){
        if(fs.existsSync(visitorLogPath)){
            fs.unlinkSync(visitorLogPath);
            res.write("visitor file deleted successfully");
        }else{
            res.write("visitor File does not exists");
        }
        res.end();
    }else if(url === "/system-info"){
        console.log(os.cpus());
        res.write(JSON.stringify({
            "Hostname" : os.hostname(),
            "OS Platform" : os.platform(),
            "CPU Model" : os.cpus()[0].model,
            "Number of cores" : os.cpus().length,
            "total memory" : os.totalmem(),
            "free memory" : os.freemem(),
            "uptime" : os.uptime()
        }));
        res.end();
    }else{
        res.write("404 Page not found");
        res.end();
    }

});


server.listen(PORT,()=>console.log("Server listening at port ",PORT));