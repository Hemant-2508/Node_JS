const http = require("http");
const path = require("path");
const fs = require("fs");

const logFileName = "log.txt";
const visitFileName = "visit.json";

const dirPath = __dirname;

const logFilePath = path.join(dirPath, logFileName);
const visitFilePath = path.join(dirPath, visitFileName);

let counter = { count: 0 };

// create visit file if not exists
if (!fs.existsSync(visitFilePath)) {
    fs.writeFileSync(visitFilePath, JSON.stringify(counter));
}

const server = http.createServer((req, res) => {

    const url = req.url;
    const method = req.method;
    const date = new Date().toLocaleString();

    const log = `[${date}] ${method} ${url}\n`;

    fs.appendFile(logFilePath, log, () => {});

    if (url === "/visit") {

        fs.readFile(visitFilePath, "utf-8", (err, data) => {

            let counter = JSON.parse(data);

            counter.count++;

            fs.writeFile(visitFilePath, JSON.stringify(counter), () => {});

            res.write("This is Visit page");
            res.end();
        });

    }

    else if (url === "/count") {

        fs.readFile(visitFilePath, "utf-8", (err, data) => {

            const counter = JSON.parse(data);

            res.write(`Total Visits: ${counter.count}`);
            res.end();
        });

    }

    else if (url === "/reset") {

        const counter = { count: 0 };

        fs.writeFile(visitFilePath, JSON.stringify(counter), () => {});

        res.write("Visit Counter Reset Successfully");
        res.end();

    }

    else if (url === "/favicon.ico") {

        res.end(); // ignore favicon

    }

    else {

        res.write("404 Route not Found");
        res.end();

    }

});

const PORT = 7000;

server.listen(PORT, () => {
    console.log("Connected Successfully at Port", PORT);
});