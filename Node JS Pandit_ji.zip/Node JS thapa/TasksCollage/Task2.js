const path = require("path");
const fs = require("fs");
const http = require("http");
const url1 = require("url");
const PORT = 7000;
const filePath = path.join(__dirname,"notes.txt");


const server = http.createServer((req,res)=>{

    const url = url1.parse(req.url,true).pathname;
    const query = url1.parse(req.url,true).query;
    if(url === "/add"){
        if(query['note']){
            fs.appendFileSync(filePath,query["note"]+"\n","utf-8"); 
            res.write("Note Added Successfully")
        }else{
            res.write("400 Bad Request");
        }
        res.end();
    }else if(url === "/notes"){
        if(!fs.existsSync(filePath)){
            res.write("No Notes Found");
        }else{
            const data  = fs.readFileSync(filePath,"utf-8");
            if(data === "" && !data){
                res.write("No Notes Found");
            }else{
                res.write(data);
            }
        }
        res.end();
    }else if(url === "/clear"){
        fs.writeFileSync(filePath,"","utf-8");
        res.write("All notes Deleted");
        res.end();
    }else{
        res.write("404 Route Not Found");
        res.end();
    }

});

server.listen(PORT,()=>console.log("sever listening at port ",PORT));