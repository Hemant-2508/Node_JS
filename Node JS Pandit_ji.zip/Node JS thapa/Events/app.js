const fs = require("fs");
const EventEmitter = require("events");
const { log } = require("console");

// Create an instance of EventEmitter
const emitter = new EventEmitter();
//1. Define an event listner(addListener)
// emitter.on("greet", ()=> {
//     console.log("Hello, Rahul");
// });
// 2. Trigger (emit) the "greet" event
// emitter.emit("greet");

// hello Rahul

// you can also pass arguments

// emitter.on("greet",(data)=>{
//     console.log(`Hello, ${data}`);
// })

// emitter.emit("greet","Rahul Singh");



// we can also pass an object to the emmiter


emitter.on("greet",(details)=>{
    console.log(`Hello, My name is ${details.name}, i am a ${details.prof}`)
})

const details = {
    name : "Rahul Singh",
    prof : "Web developer"
}
emitter.emit("greet",details);