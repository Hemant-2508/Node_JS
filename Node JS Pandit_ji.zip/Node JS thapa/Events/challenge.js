const { log } = require("console");
const EventEmitter = require("events");
const fs = require("fs");
const path = require("path");

const fileName = "log.txt";
const filePath = path.join(__dirname,fileName);

const emitter = new EventEmitter();

const eventCounts = {
    "user-login" : 0,
    "user-logout" : 0,
    "user-purchase" : 0,
    "profile-update" : 0
};

const data = async()=>{
    try{
        const data = fs.promises.readFile(filePath,"utf-8");
        data.then(res => {
            
        })
    }catch(err){
        console.log(err);
        
    }
}




emitter.on("user-login",(name)=>{
    eventCounts["user-login"]+=1;
    console.log(name);
});

emitter.on("user-purchase",(username, purchase)=>{
    eventCounts["user-purchase"]+=1;
    console.log(`${username} purchases a ${purchase}`);
})

emitter.on("profile-update",(usernamne,updation)=>{
    eventCounts["profile-update"]+=1;
    console.log(`${usernamne} updated his ${updation}`);
})

emitter.on("user-logout",(username)=>{
    eventCounts["user-logout"]+=1;
    console.log(`${username} successfully logged out`);
})

emitter.on("summary",()=>{
    writeFile(eventCounts);

})

const writeFile = async(eventCounts)=>{
    try{
        const data = JSON.stringify(eventCounts)+"\n";
        await fs.promises.writeFile(filePath,data,"utf-8");
        console.log("file updated successfully");
    }catch(err){
        console.error(err);
    }
}




emitter.emit("user-login","Thapa");
emitter.emit("user-purchase","Thapa","Laptop");
emitter.emit("profile-update","Thapa","email");
emitter.emit("user-logout","Thapa");
emitter.emit("summary");
emitter.emit("summary");


