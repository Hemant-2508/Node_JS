

const add = (a,b) => {
    return a+b;
};
const sub = (a,b) => {
    return a-b;
};
export const mul = (a,b) => {
    return a*b;
};
const div = (a,b) => {
    return a/b;
};

const PI = 3.124;

// export default mul;