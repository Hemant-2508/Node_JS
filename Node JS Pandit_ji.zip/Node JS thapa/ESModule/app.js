// import mul from "./math.js"
import { mul } from "./math.js";

// console.log(math.add(5,6));

// console.log(math.sub(5,8));
// console.log(math.PI)
console.log(mul(2,9));