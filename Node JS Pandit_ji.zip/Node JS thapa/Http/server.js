const http = require("http");

const server = http.createServer((req,res)=>{
    if(req.url === '/'){
        res.setHeader("Content-Type","text/plain");
        res.write("I am rahul singh this is home page");
        res.end();
    }else if(req.url === '/about'){
        res.write("this is about page");
        res.end();
    }else if(req.url === "/homepage"){
        res.write("This is HomePage");
        res.end();
    }else{
        res.write("404 Page not found");
        res.end();
    }
});

// server.emit()





const PORT = 3000;
server.listen(PORT,()=>{
    console.log(`Listening on PORT ${PORT}`);
})