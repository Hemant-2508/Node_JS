const { log } = require("console");
const fs = require("fs");
const path = require("path");

const fileName = "fspromises.txt";
const filePath = path.join(__dirname,fileName);

// const file = __dirname;

// fs.promises.readdir(file)
//     .then((data)=>{
//         console.log(data)})
//     .catch((err)=>{
//         console.error(err);
// })



// fs.promises.readdir(__dirname).then((data)=> console.log(data)).catch((err)=> console.log(err));


fs.promises.writeFile(filePath,"Writing file for the first time","utf-8").then(console.log("File crated successfully.")).catch((err)=>console.log(err))
fs.promises.readFile(filePath,"utf-8").then((data)=>console.log(data)).catch((err)=>console.error(err));
fs.promises.appendFile(filePath,"\nappending data to the file","utf-8").then(console.log("data appended successfully")).catch((err)=>console.error(err));
fs.promises.unlink(filePath).then(console.log("File deleted successfully")).then((err)=>console.error(err));