const { log } = require("console");
const fs = require("fs");
const path = require("path");

const fileName = "fsAsync.txt";
const filePath = path.join(__dirname,fileName);

const writeFileAsync = fs.writeFile(filePath,"this is initial file","utf-8",(err)=>{
    if(err) console.error(err);
    else console.log("File has be created");
    
})

// read file in Async

const readFile = fs.readFile(filePath,"utf-8",(err,data)=>{
    if(err) console.error(err);
    else console.log(data);
})

console.log(readFile);


// How to append data 

const appendData = fs.appendFile(filePath,"\n this is the data that is needed to be append",(err)=>{
    if(err) console.error(err);
    else console.log("File has been updated")
})


// const unlink = fs.unlink(filePath,(err)=>{
//     if(err) console.error(err);
//     else console.log("File has been deleted successfully");
// })

// const rename = fs.rename()