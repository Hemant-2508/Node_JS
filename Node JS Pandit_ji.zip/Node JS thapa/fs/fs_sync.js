// fs system

//C R U D operation

// how to create a file

// const { log } = require("console");
const fs = require("fs");
const path = require("path");

const fileName = "text.txt";
const filePath = path.join(__dirname,fileName);

const writeFile = fs.writeFileSync(filePath,"This is the initial Data","utf-8");


// console.log(writeFile);
// how to read data of the file

// const filePath = path.join(__dirname,"text.txt");

const readFile = fs.readFileSync(filePath,"utf-8")
console.log(readFile.toString());



// how to add data to the file or append data to file

const appendData = fs.appendFileSync(filePath,"\nhow are you doing","utf-8");
console.log(appendData);


// how to delete file

// const unlink = fs.unlinkSync(filePath);
// console.log(unlink);


// how to change file name or rename a file

const newUpdatedName = "updatedTest.txt";
const newfilePath = path.join(__dirname,newUpdatedName);
const renameFile = fs.renameSync(filePath,newfilePath);

