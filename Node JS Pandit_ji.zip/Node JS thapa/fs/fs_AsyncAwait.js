const { log } = require('console');
const fs = require('fs');
const path = require("path");

const fileName = "fsAsyncAwait.txt";
const filePath = path.join(__dirname,fileName);


// const readFolder = async()=>{
//     try{
//         const res = await fs.promises.readdir(__dirname);
//         console.log(res);
//     }catch(err){
//         console.error(err);
//     }
// }

// readFolder();


const writeFile = async()=>{
    try{
        await fs.promises.writeFile(filePath,"this is the first time when file is being written","utf-8");
        console.log("File has been written successfully");
    }catch(err){
        console.error(err);
    }
}

writeFile();

const readFile = async()=>{
    try{
        const data = await fs.promises.readFile(filePath,"utf-8");
        console.log(data);
    }catch(err){
        console.error(err);
    }
}

readFile();



const appendData = async ()=>{
    try{
        await fs.promises.appendFile(filePath,"\nthis data is being appeded to the file.","utf-8");
        console.log("file is successfully appended");
    }catch(err){
        console.error(err);
    }
}
appendData();